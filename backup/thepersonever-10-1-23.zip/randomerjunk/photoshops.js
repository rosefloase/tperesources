function hide(){
   document.getElementById('bigimg').innerHTML = ''; 
   document.getElementById('skippy').setAttribute("width", "300px");
   document.getElementById('spirithell').setAttribute("width", "300px");
   document.getElementById('thanksnotreal').setAttribute("width", "300px");
   document.getElementById('viewmonster').setAttribute("width", "300px");
   document.getElementById('wall').setAttribute("width", "300px");
   document.getElementById('monstermonster').setAttribute("width", "300px");
   document.getElementById('car').setAttribute("width", "300px");
   document.getElementById('peter').setAttribute("width", "300px");
   document.getElementById('california').setAttribute("width", "300px");
}

function hunpix(){
     document.getElementById('spirithell').setAttribute("width", "100px"); 
   document.getElementById('thanksnotreal').setAttribute("width", "100px");
   document.getElementById('viewmonster').setAttribute("width", "100px");
   document.getElementById('wall').setAttribute("width", "100px");
   document.getElementById('monstermonster').setAttribute("width", "100px");
   document.getElementById('car').setAttribute("width", "100px");
   document.getElementById('peter').setAttribute("width", "100px");
   document.getElementById('california').setAttribute("width", "100px");
   document.getElementById('skippy').setAttribute("width", "100px");
}

function skippy(){
 document.getElementById('bigimg').innerHTML = '<img src=/images/musicicon.png height=500px onclick=hide()>';  
  hunpix();
}

function spirithell(){
 document.getElementById('bigimg').innerHTML = '<img src=https://i.imgur.com/6XmsMCk.jpg height=500px onclick=hide()>';  
  hunpix();
}

function thanksnotreal(){
 document.getElementById('bigimg').innerHTML = '<img src=https://i.imgur.com/GWmpJk5.png height=500px onclick=hide()>';  
  hunpix();
}

function viewmonster(){
 document.getElementById('bigimg').innerHTML = '<img src=https://i.imgur.com/aGQFtQt.jpg height=500px onclick=hide()>';  
  hunpix();
}

function wall(){
 document.getElementById('bigimg').innerHTML = '<img src=https://i.imgur.com/ixCyvpM.png height=500px onclick=hide()>';  
  hunpix();
}

function monstermonster(){
 document.getElementById('bigimg').innerHTML = '<img src=https://i.imgur.com/4kkS9xq.jpg height=500px onclick=hide()>';  
  hunpix();
}

function car(){
 document.getElementById('bigimg').innerHTML = '<img src=https://i.imgur.com/rt1wxP6.jpg height=500px onclick=hide()>';  
  hunpix();
}

function peter(){
 document.getElementById('bigimg').innerHTML = '<img src=https://i.imgur.com/SIyDEqc.jpg height=500px onclick=hide()>';  
  hunpix();
}

function california(){
 document.getElementById('bigimg').innerHTML = '<img src=https://i.imgur.com/6EU1A40.jpg height=500px onclick=hide()>';  
  hunpix();
}

/*<img src=https://i.imgur.com/6XmsMCk.jpg width=300px id="spirithell" onclick="spirithell()">
<img src=https://i.imgur.com/GWmpJk5.png width=300px id="thanksnotreal" onclick="thanksnotreal()">
<img src=https://i.imgur.com/aGQFtQt.jpg width=300px id="viewmonster" onclick="viewmonster()">
<img src=https://i.imgur.com/ixCyvpM.png width=300px id="wall" onclick="wall()">
<img src=https://i.imgur.com/4kkS9xq.jpg width=300px id="monstermonster" onclick="monstermonster()">
<img src=https://i.imgur.com/rt1wxP6.jpg width=300px id="car" onclick="car()">
<img src=https://i.imgur.com/SIyDEqc.jpg width=300px id="peter" onclick="peter()">
<img src=https://i.imgur.com/6EU1A40.jpg width=300px id="california" onclick="california()">
</div>*/
