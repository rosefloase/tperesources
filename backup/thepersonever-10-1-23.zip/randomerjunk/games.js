// consoles

function nswitch() {
 document.getElementById('title').innerHTML= '<span>switch</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/G9UeDBW.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>whoohoo ^_^ <br> i dont have much to say about any of these consoles anymore so uh <br> :P <br></span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/pcb.jpg)';
}

function wiiu() {
 document.getElementById('title').innerHTML= '<span>wii u</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/EaJQYEA.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>oh boy oh boy i love the wii u <br> i softmodded mine, and put pikmin 3 on it. thats the only reason i softmodded it. i swear</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/pcb.jpg)';
}

function wii() {
 document.getElementById('title').innerHTML= '<span>wii</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/ZPLfTGf.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>softmodded to play Not Just Wii Games! <br> this is how i played pikmin when i was like 12 because. i did not have a good enough computer to emulate it <br> i use it as my primary emulation <i>console</i>, because its set up to my crt, and i have a clasic controller pro <br> so uh! yeah. its cool :)</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/pcb.jpg)';
}

function xboxthreesix() {
 document.getElementById('title').innerHTML= '<span>xbox 360</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/KTDrLRi.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>the console i have the most games for <br> aka i have every halo game up to reach <br> i havent used it since i finished the series...</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/pcb.jpg)';
}

function ps3() {
 document.getElementById('title').innerHTML= '<span>ps3</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/r56uNB9.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i have like one game for this console and its. not all that fun so</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/pcb.jpg)';
}

function gamecube() {
 document.getElementById('title').innerHTML= '<span>gamecube</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/732cKz7.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i dont really play this that much, considering i have a wii... <br> its nice for the physical gamecube games i have though! you dont have to fumble around with a wiimote <br> ill get a gameboy player... someday :3</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/pcb.jpg)';
}

function ps2(){
 document.getElementById('title').innerHTML= '<span>ps2</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/OeGKzZt.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this console is so <br> i got it by trading in 2 ds lites i got at a thrift store</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/pcb.jpg)';
}

function dreamcast(){
 document.getElementById('title').innerHTML= '<span>dreamcast</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/YGVSA78.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>uh! this console is. cool uh <br> i dont really use the vmus too much but... <br> the games are fun :)))</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/pcb.jpg)';
}

function snes(){
 document.getElementById('title').innerHTML= '<span>soupa nintendo</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/KeJIwzb.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>gleh <br> ive had this thing since i was like 3... <br> plok is so</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/pcb.jpg)';
}

function genesis(){
 document.getElementById('title').innerHTML= '<span>genesis</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/ENtJS8Y.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>SIXTEEN BIT HIGH DEFINITION GRAPHICS <br> why are the controller chords so short... why...</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/pcb.jpg)';
}

function threeds(){
 document.getElementById('title').innerHTML= '<span>3ds</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/kvgwYQq.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>woo i LOVE the 3ds!!! <br> softmodded it after the 3ds shop closed... i can now play hey pikmin i guess :P</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/pcb.jpg)';
}

function dsi(){
 document.getElementById('title').innerHTML= '<span>dsi</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/aZp9KE3.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>flipnote my beloved <br> ignited my love for digital drawing and animation... its also where i play most of my ds games, due to having bigger screens than the ds lite, and not having the pixel scale issue that the 3ds has <br> i made that decal when i was 11 (i think???) dont judge me</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/pcb.jpg)';
}

function dslite(){
 document.getElementById('title').innerHTML= '<span>ds lite</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/PPuwHwY.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>mmmmm <br> mainly just use this to play gba games... blehg</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/pcb.jpg)';
}

//switch games

function cb4modern(){
 document.getElementById('title').innerHTML= '<span>crash 4 - its about time</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/vZtAXTx.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>sigh <br> this game will never be the mediocre crash 4 that we all deserve to me</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/botw.jpg)';
}

function cbinsane3(){
 document.getElementById('title').innerHTML= '<span>crash bandicoot n-sane trilogy</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/Ky8oqRy.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>yes i had a caddicarus induced crash bandicoot phase at 12 years old hasnt everyone</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/botw.jpg)';
}

function kandtfg(){
 document.getElementById('title').innerHTML= '<span>kirby and the forgotten land</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/NmSIMVy.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this is the first only and last game ive bought at best buy that place is like a microcenter for people who dont live near a microcenter. i dont live near a microcenter or a  best buy <br> switch games are 50 dollars at walmart did you know that... <br> anyways i like this game :) its fun!</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/botw.jpg)';
}

function mk8d(){
 document.getElementById('title').innerHTML= '<span>mariokart 8 deluxe</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/yIU9hzp.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>mariokart 8 but portable! but actually this time! <br> actually there are a few diffrences but. the only differences are that there are 2 item slots now and that the battle mode isnt the absolutly worst thing ive ever played <br> also the dlc is included on the cart <br> also also this version is still getting balancing updates. so thats fun <br> have you ever wanted to play mariokart wii without the ability to wheelie</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/botw.jpg)';
}

function mh1j(){
 document.getElementById('title').innerHTML= '<span>hits my head on the walll</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/uxGnQyy.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>sighhh <br> i got this game because my dad likes anime and i thought he would like this <br> i dont know why i did that since we play mariokart together usually but <br> why am i judging this i like homestuck thats like. worse i think? allegedly?</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/botw.jpg)';
}

function pikmin4(){
 document.getElementById('title').innerHTML= '<span>pikmin 4</span>' ;
 document.getElementById('bigimg').innerHTML= '<img https://i.imgur.com/uxGnQyy.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>my parents got me 60 dollars worth of eshop credit on launch day because they went to hyvee instead of walmart. im still kinda mad about that but Oh Well!</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/botw.jpg)';
}

function p3d(){
 document.getElementById('title').innerHTML= '<span>pikmin 3 deluxe</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/j6FqMfq.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this is not a good port im sorry <br> the controlls are. fine i guess. but god this game was not meant for gamecube + manual lock-on controls <br> also im too lazy to change gyro sensitivity. and gyro is the WORST in portable mode so <br> yeah</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/botw.jpg)';
}

function pmdrtdx(){
 document.getElementById('title').innerHTML= '<span>pokemon mystery dungeon - rescue team dx</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/1VPOvNz.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this is the only pmd game on switch. a remake with, compared to the 2006 versions, eh visuals and almost unupgraded audio from the 3ds games. even though the switch has the most robust sound system of any nintendo handheld. sigh</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/botw.jpg)';
}

function pkmnsword(){
 document.getElementById('title').innerHTML= '<span>pokemon sword</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/5lwhMIM.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>my parents got me this for christmas 2021 (i think?) and i have not played it since</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/botw.jpg)';
}

function pokkendx(){
 document.getElementById('title').innerHTML= '<span>pokkén tournament dx</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/5t9Cqed.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>like. a year ago my mom wouldnt let me get a gba sp and i was so mad i made her buy this instead???????</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/botw.jpg)';
}

function splat2(){
 document.getElementById('title').innerHTML= '<span>splatoon 2</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/gK9i6DS.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>for some reason i remember being really into splatoon 1 but. not excited at all for 2 <br> i got the version with the art book :)</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/botw.jpg)';
}

function smodyssey(){
 document.getElementById('title').innerHTML= '<span>super mario odyssey</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/fpasSTj.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>have you ever wanted to play as a FROG in a mario game? no? too bad</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/botw.jpg)';
}

function smm2(){
 document.getElementById('title').innerHTML= '<span>super mario maker 2</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/GRPSubN.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>its not as fluid as mario maker wii u, but at least the servers are still up! sigh...</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/botw.jpg)';
}

function ssbu(){
 document.getElementById('title').innerHTML= '<span>super smash bros. ultimate</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/8VjYUyH.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i <br> dont really have any memory of this game. sorry!</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/botw.jpg)';
}

function botw(){
 document.getElementById('title').innerHTML= '<span>the legend of zelda - breath of the wild</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/5EpIqwh.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this game SUCKS i HATE zelda <br> i put my "the" games in the t section i hate all of you</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/botw.jpg)';
}

//wii u games

function injustice(){
 document.getElementById('title').innerHTML= '<span>injustice: gods among the :/ emoticon</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/gBrcfnV.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this game is the lamest thing ever <br> i think my parents got this version because it was cheaper than the 360 version maybe??? but we dont even have multiple wii u controllers so. yeah</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/udisk.jpg)';
}

function ldimensions(){
 document.getElementById('title').innerHTML= '<span>lego dimensions</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/9SeLrXx.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>oh yeah i had a toys to life phase <br> i thought this game was cool because they used actual legos and. legos are actually things you can play with i guess! so i thought that was nice</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/udisk.jpg)';
}

function mp10(){
 document.getElementById('title').innerHTML= '<span>mario party 10</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/IE2T7uS.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this was my first mario party game <br> can you see why i dont like mario party :(</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/udisk.jpg)';
}

function mk8(){
 document.getElementById('title').innerHTML= '<span>mariokart 8</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/68d40IA.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>mariokart 8 is so good its like hd mariokart 7 you should play it! it has musical stems</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/udisk.jpg)';
}

function nsmbu(){
 document.getElementById('title').innerHTML= '<span>new super mario bros. u</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/B5QAVEE.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i got this because i wanted to buy a wii u game at the closest games store but there wasnt anything i didnt have or want other than this. <br> i am not going to get the switch version</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/udisk.jpg)';
}

function nintendoland(){
 document.getElementById('title').innerHTML= '<span>nintendo land</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/EQArppR.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i did NOT get this with my wii u i got the super mario maker bundle which included a download code for super mario maker because. thats the game i saw on tv and was like "OH MY GOD I NEED THAT" so thats what my parents got me. <br> i bought this used</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/udisk.jpg)';
}

function pmcs(){
 document.getElementById('title').innerHTML= '<span>paper mario - color splash</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/7wEgbe4.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i didnt finish this game <br> i thought the card gimmic was fun though because. im a wii u kid. also i was like 9 when i got my parents to buy this for me so i dont really remember the writing being stellar or whatever</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/udisk.jpg)';
}

function sm3dw(){
 document.getElementById('title').innerHTML= '<span>super mario 3d world. meeeeeoww!</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/CabhRGQ.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i beat like 90% of this game at my cousin&apos;s house and i thought it was fun. when i finally had MONEY i bought this because i remembered it being fun and. its not fun but its not unfun</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/udisk.jpg)';
}

function smash4u(){
 document.getElementById('title').innerHTML= '<span>super smash bros. (for wii u!)</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/3GW4O3Z.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this was my first smash game <br> i remember the christmas i got the wii u me and the Extended Family tried to play 8 player smash and i tried to use the dpad to move and the a button to jump</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/udisk.jpg)';
}

function starfoxguard(){
 document.getElementById('title').innerHTML= '<span>star fox guard</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/POEkula.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i got my mom to buy me this at a goodman&apos;s because. it was a video game at a goodman&apos;s. <br> what even is goodman&apos;s</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/udisk.jpg)';
}

function yww(){
 document.getElementById('title').innerHTML= '<span>yoshi&apos;s woolly world</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/F9Imeiq.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i have not played this again yet due to FOURTEEN YEAR OLD WITH NOSTALGA EVERYONE MAKE FUN OF HER SHES 14 YEARS OLD!!!! <!--<br> image placeholder of that one conversation. with yoshi kinning. you know the one me --></span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/udisk.jpg)';
}

//wii games

function gameparty3(){
 document.getElementById('title').innerHTML= '<span>game party 3</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/aCS7PYK.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i dont remember how this game was bought, but i do know that this game is horrible!</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/wiiflix.jpg)';
}

function mkwii(){
 document.getElementById('title').innerHTML= '<span>mariokart wii</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/E82PBo7.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>I LOVE THIS GAME wags my tail <br> this is the mariokart im best at (i am not at all good enough for competitive play)</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/wiiflix.jpg)';
}

function nsmbwii(){
 document.getElementById('title').innerHTML= '<span>new super mario bros. wii</span>' ; //fun fact this game relased the year i was born! should i kill myslef
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/E82PBo7.jpg width=500px>' ; // -jade
 document.getElementById('desc').innerHTML= '<span>this game is. eh. <br> i like it i mean but i just never felt the need to beat it <br> i also tried to do a pseudo</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/wiiflix.jpg)';
}




//360 games

//ps3 games

function uncharted(){
 document.getElementById('title').innerHTML= '<span>uncharted</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/B2LbTPp.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>sigh... <br> sorry everyone i dont like this game :(</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/ps3.jpeg)';
}

//xbox games

function burnout3(){
 document.getElementById('title').innerHTML= '<span>burnout 3 - takedown</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/eHVuHBC.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i got this game because my parents took me to like. a store far away from where i lived and i was like "well i need to say i got something out of this trip..." so. yeah <br> its fine i dont really like racers <br> ignore the ps3 in the background</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/ps3.jpeg)';
}

function haloce(){
 document.getElementById('title').innerHTML= '<span>halo - combat evolved</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/2LFVO4g.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>the collector in me is showing <br> did you know that the non game of the year versions of this game are extremely rare? allegedly</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/ps3.jpeg)';
}

function halo2(){
 document.getElementById('title').innerHTML= '<span>halo 2</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/F5iw97E.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this game. is fine i beat halo 3 before i beat this game <br> this game is fine okay its ALRIGHT. okay?</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/ps3.jpeg)';
}

function hitandrun(){
 document.getElementById('title').innerHTML= '<span>the simpsons - hit and run</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/ekRRTYa.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>eh <br> why did i buy this game</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/ps3.jpeg)';
}

//gamecube / gc games

function gerouge(){
 document.getElementById('title').innerHTML= '<span>goldeneye - rouge agent</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/ymmLfTJ.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>there wer&apos;nt any good games for me to justify my gamecube purchase with so i got this</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/gcdisk.jpg)';
}

function nmgc(){
 document.getElementById('title').innerHTML= '<span>namco museum</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/EIVrbLo.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>oh man this game is so cool at my parent&apos;s friend&apos;s house! <br> oh my god this game sucks</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/gcdisk.jpg)';
}

function sms(){
 document.getElementById('title').innerHTML= '<span>super mario sunshine</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/kGOIfgT.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>sighs <br> this game is so good i need to get better at the movement</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/gcdisk.jpg)';
}

function thunderground(){
 document.getElementById('title').innerHTML= '<span>tony hawk&apos;s underground</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/j9UPDMg.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this game is. alright i guess its not my cup of tea</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/gcdisk.jpg)';
}

//dreamcast games

function crazytaxi(){
 document.getElementById('title').innerHTML= '<span>crazy taxi</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/cHqgVto.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>got this with my dreamcast uh <br> its! alright. im not that good at it yet, but i think its quite fun :3</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dang.png)';
}

function sonicadventure(){
 document.getElementById('title').innerHTML= '<span>sonic adventure</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/A3YuJ7h.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i also got this with my dreamcast... i distinctly remember beating the final boss at like 5 am one night. i love this game :D</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dang.png)';
}

function sa2(){
 document.getElementById('title').innerHTML= '<span>sonic adventure 2</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/b9weE3K.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i bought this disk-only for 70 dollars. a version with the case would be $110... <br> i did buy a repo case on etsy though! <br> 10 times better than sa1...  i love this game a slightly unhealthy amount. no longer hyperfixated on it but</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dang.png)';
}

function soulcalibur(){
 document.getElementById('title').innerHTML= '<span>soul calibur</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/0Lxcjij.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>mmm this game is. alright <br> not sure what to say about it... im not really into fighting games <br> i think its fun enough at least! :)</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dang.png)';
}

function dcwebbrowser(){
 document.getElementById('title').innerHTML= '<span><span>dreamcast web browser!</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/vvRqYmF.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i thought there would be at least some content on the disk when i bought it... i was wrong :(</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dang.png)';
}

//ps1 games

//snes games

function sigh(){
 document.getElementById('title').innerHTML= '<span>I HATE THIS GAME</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/Lf75Att.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>GAHHHHHHHHH i have not played this game since 2016</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/chronobleh.jpg)';
}

function dkc(){
 document.getElementById('title').innerHTML= '<span>donkey kong country</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/WMPNUBh.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>honestly this game is really fun even if it is tough at times <br> it looks nice on a crt you should try it that way if you can :)</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/chronobleh.jpg)';
}

function dkc2(){
 document.getElementById('title').innerHTML= '<span>donkey kong country 2</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/WSMcrdc.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i got this AND the box for it at a thrift store for 5 dollars???? giggles <br> i have not beaten it yet sorry everyone</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/chronobleh.jpg)';
}

function dkc2(){
 document.getElementById('title').innerHTML= '<span>donkey kong country 2</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/WSMcrdc.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i got this AND the box for it at a thrift store for 5 dollars???? giggles <br> i have not beaten it yet sorry everyone</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/chronobleh.jpg)';
}

function fzero(){
 document.getElementById('title').innerHTML= '<span>f-zero</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/mFVKJ9E.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>my dad&apos;s friend got this and gave it to me because he doesnt have an snes anymore <br> i like this game so much more than super mario kart... im still not good at it though</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/chronobleh.jpg)';
}

function mmpr(){
 document.getElementById('title').innerHTML= '<span>mighty morphing who the hell</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/jS6BxwL.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>sighs deeply <br> i liked this game when i was 8. i did not watch power rangers nor did i have any power ranger toys</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/chronobleh.jpg)';
}

function mmprtm(){
 document.getElementById('title').innerHTML= '<span>mighty morphing power rangers the movie the video game</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/Mn6fPLw.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>THIS is better than the other game <br> its still not good</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/chronobleh.jpg)';
}

function mariopaint(){
 document.getElementById('title').innerHTML= '<span>mario paint</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/Y6WrCZI.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>woohoo this game is soooo silly!!!! <br> yes i have the mouse i would be unable to play the game if i didnt :/</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/chronobleh.jpg)';
}

function plok(){
 document.getElementById('title').innerHTML= '<span>plok</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/0j4Txsf.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>plok is so</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/chronobleh.jpg)';
} 

function ramen(){
 document.getElementById('title').innerHTML= '<span>whats this game&apos;s name??????????</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/rLcgh1N.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this game is. not great its like a fighting game on a budget <br><br> <img src=https://i.imgur.com/6V8UJk7.jpg width=500px> <br> oh thats it&apos;s name</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/chronobleh.jpg)';
}

function dvr(){
 document.getElementById('title').innerHTML= '<span>road runner&apos;s death valley rally</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/c9CCY2R.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this game is eh. why did my Relatives love looney toons so much</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/chronobleh.jpg)';
}

function ssf2(){
 document.getElementById('title').innerHTML= '<span>super street fighter 2</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/sDwAuv4.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>im not really a big fighting game fan but this game is fun :D</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/chronobleh.jpg)';
}

function smw(){
 document.getElementById('title').innerHTML= '<span>super mario world</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/w4zf3tN.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i bought this game separately what is it with me and not owning pack-in games</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/chronobleh.jpg)';
}

function allstars(){
 document.getElementById('title').innerHTML= '<span>super mario all stars</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/gMswi5P.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>THIS IS THE GREATEST GAME OF ALL TIME I DONT NEED AN NES!!!!! i love you mother uncle and aunt for owning this super nintendo before me</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/chronobleh.jpg)';
}

//genesis games

function mortalk1(){
 document.getElementById('title').innerHTML= '<span>mortal kombat</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/yYQLezc.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i got this because i needed SOMETHING to justify getting a genesis besides sonic games so. i got blood</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/reelmonstarz.png)';
}

function sonic2(){
 document.getElementById('title').innerHTML= '<span>sonic 2</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/wJRL4XT.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>shows you my hedge-shaped birthmark that appeared when i was 12. it has been there since birth i swear</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/reelmonstarz.png)';
}

function sandk(){
 document.getElementById('title').innerHTML= '<span>sonic and knuckles</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/FkMeSX0.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this game is. great. yeah. <br> im not sick what are you TALKING abotu</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/reelmonstarz.png)';
}

function maxcarnage(){
 document.getElementById('title').innerHTML= '<span>spiderman - maximum carnage</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/mBNQuXY.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i saw reviews of this game from 2006 and they all said it was good so i bought it. its fine i guess</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/reelmonstarz.png)';
}

function tazmania(){
 document.getElementById('title').innerHTML= '<span>taz mania based off of the hit series taz-mania</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/BVKePvg.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this game. is not great. i dont know why i bought it</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/reelmonstarz.png)';
}

//nes games

function spyhunter(){
 document.getElementById('title').innerHTML= '<span>spyhunter</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/QallFIf.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>good god this game is the lamest thing ever</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/gyromite.jpg)';
}

function dd3(){
 document.getElementById('title').innerHTML= '<span>double dragon 3</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/rJZcoag.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>neat little fighting game! i have not gotten past the first room</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(images/gyromite.jpg)';
}

//3ds games

function ac3ds(){
 document.getElementById('title').innerHTML= '<span>animal crossing - new leaf</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/xcYkOqU.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i have not played this game in so long my villagers are probably so scared</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/games/3dscart.jpg)';
}

function kbr(){
 document.getElementById('title').innerHTML= '<span>kirby battle royale</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/Ol9bIDQ.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this game is so. its eh its fine i dont really like it though</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/games/3dscart.jpg)';
}

function ktd(){
 document.getElementById('title').innerHTML= '<span>kirby triple deluxe</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/fKWBoNO.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this game is great :D <br> i have this itch where i NEED to 100% this game. keychains are eating up allll of my playcoins</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/games/3dscart.jpg)';
}

function mk7(){
 document.getElementById('title').innerHTML= '<span>mariokart 7</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/KiBlTDP.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>mariokart 8 on the go! without anti gravity! :( <br> this game is alright i like a lot of the track designs</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/games/3dscart.jpg)';
}

function pus(){
 document.getElementById('title').innerHTML= '<span>pokemon ultra sun</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/QYLA2iL.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this game is lame i dont like it sorry everyone</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/games/3dscart.jpg)';
}

function psmd(){
 document.getElementById('title').innerHTML= '<span>pokemon super mystery dungeon</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/6Ch4juX.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i got this game from my local library when i was. younger and i was like OH MY GOD I LOVE THIS and i have loved pmd ever since :)</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/games/3dscart.jpg)';
}

function mandlss3ds(){
 document.getElementById('title').innerHTML= '<span>mario and luigi - superstar saga (3ds remake)</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/rhcJolR.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this game is very fun! i feel like. im missing out by not playing the gba version though. <br> remakes are not replacements remakes are not replacements REMAKES ARE NOT REPLACEMENTS</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/games/3dscart.jpg)';
}

function sm3dl(){
 document.getElementById('title').innerHTML= '<span>super mario 3d land!</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/emLCG7n.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>its like nsmb but 3d :) i think its fun</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/games/3dscart.jpg)';
}

function smash3ds(){
 document.getElementById('title').innerHTML= '<span>super smash bros. for 3ds</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/CgGWe4b.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>smash 4 but portable! its alright i guess i think i would like it more if i had a circle pad pro instead of a new 3ds nub <br> yes im one of those people I LOVE PIKACHU&apos;S AERIALS</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/games/3dscart.jpg)';
}

//ds games

function atds(){
 document.getElementById('title').innerHTML= '<span>adventure time - hey ice king! why&apos;d you steal our garbage?!</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/VIdQVFY.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this was the greatest thing ever to 11 year old me. she had never watched adventure time <br> theres also a 3ds version but i think the only change is that the audio is enhanced... and its in widescreen :P</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function cpepf(){
 document.getElementById('title').innerHTML= '<span>club penguin - elite penguin force</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/8gzscmN.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i dont know why i bought this </span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function ghds(){
 document.getElementById('title').innerHTML= '<span>guitar hero - on tour</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/a54Mz7b.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>everyone had a guitar hero phase! or at least i hope i dont want to be the only one</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function kma(){
 document.getElementById('title').innerHTML= '<span>kirby mass attack</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/zHCxOpo.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>MMM good game :) you should play it i think its fun</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function mandlbis(){
 document.getElementById('title').innerHTML= '<span>mario and luigi - bowser&apos;s inside story</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/oWhV2My.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i love mario and luigi. i dont think this is the best mario and luigi experience though <br> you only really play as bowser in the outside world, because mario and luigi are trapped <i>inside</i> of bowser... so its not a great introduction to the mario and luigi style. play this one after you play one of the other m&l games :(</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function mkds(){
 document.getElementById('title').innerHTML= '<span>mariokart ds</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/ZnzdT6W.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>have you ever driven a car. i assume this game is a lot like that</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function mpds(){
 document.getElementById('title').innerHTML= '<span>mario party ds</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/KDT8WBn.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i got this game for free with a ds i bought from a thrift shop! <br> i dont really like this game but i think thats just because its mario party. i dont really like mario party</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function mmzx(){
 document.getElementById('title').innerHTML= '<span>megaman zx</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/aej8cyo.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span> honestly its been so long since ive played this game i forgot everything about it <br> i remember it being pretty fun at least... </span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function nsmbds(){
 document.getElementById('title').innerHTML= '<span>new super mario bros.</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/U9BFpS4.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>sigh... the best new super mario bros. game...</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function ptw(){
 document.getElementById('title').innerHTML= '<span>personal trainer - walking</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/JQSvm4p.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>it came with one of the two pedometers and the pedometer i had got washed. so it broke. best 5 dollars ive ever spent</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function pvzds(){
 document.getElementById('title').innerHTML= '<span>plants vs. zombies (ds)</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/zjb5tfO.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this version of pvz easily has the most hours put into it because it doesnt have microtransactions and the ds has a battery that lasts more than an hour</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function pbv2(){
 document.getElementById('title').innerHTML= '<span>pokemon black ver. 2</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/6J506Xp.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i also have pokemon white version 2! this was my first pokemon game and. it did not hook me</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function pmdbrt(){
 document.getElementById('title').innerHTML= '<span>pokemon mystery dungeon - blue rescue team</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/OJQl3Q2.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>I LOVE PMD! <br> this is the best version of rescue team you have two screens and it doesnt have gross 3d models</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function pmdeod(){
 document.getElementById('title').innerHTML= '<span>pokemon mystery dungeon - explorers of darkness</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/w4upq2p.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this is the best pmd game hands down it has my favorite story and it has people that like you and just. comfort game i love it</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function pwv2(){
 document.getElementById('title').innerHTML= '<span>pokemon white version 2</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/JOM6Uuy.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i also have pokemon black version 2! <br> i got both of these games on the same day funnily enough</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function sonicrush(){
 document.getElementById('title').innerHTML= '<span>sonic rush</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/OSV4LZ0.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>Nice tights! Nice new tights! Nice Tights! Got some new socks. <br> this is the greatest game ever made :) <br> <img src=https://i.imgur.com/3dcaGey.jpg width=500px> <br> i lost the cart </span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function sm64ds(){
 document.getElementById('title').innerHTML= '<span>super mario 64 ds</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/zH9rKAi.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i already had this on wii u and i chose this over animal crossing on the gamecube MY GOD</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function wwdiy(){
 document.getElementById('title').innerHTML= '<span>warioware diy</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/Yxnu7TG.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this still has games i apparently made when i was 10? i mean i feel like maybe i was older but :/</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

function wwtouched(){
 document.getElementById('title').innerHTML= '<span>warioware - touched!</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/8qgb2X5.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>the only thing i remember about this game is that its the easyest warioware i have</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dscart.jpg)';
}

//gba games

function gbacnc(){
 document.getElementById('title').innerHTML= '<span>gba video - cartoon network collection</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/hdTuG7z.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i think i just got this because i didnt have any other means of watching older cartoon network shows. this did not help <br> at least i can watch courage the cowardly dog in my basement!</span>' ;
  document.getElementById('divver').style.backgroundImage = 'url(/games/gbacart.jpg)';
}

function cbhugeadventure(){
 document.getElementById('title').innerHTML= '<span>crash bandicoot: the huge adventure. or xylophone saxophone</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/gD0zlQp.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>got this during my crash phase :P i tried to 100% this game and it hurt me physically</span>' ;
  document.getElementById('divver').style.backgroundImage = 'url(/games/gbacart.jpg)';
}

function crazytaxigba(){
 document.getElementById('title').innerHTML= '<span>crazy taxi&apos;s gba port</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/y437wWQ.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this was like. the first gba game i got... <br> uh! um uh heres 13 year old rose&apos;s justification for still owning this game <br> "i genuinely dont get the hate for this version of the game.. <br> like,, sure theres better versions of this game <br> and better gba games..  <br> but its more fun than some people give it credit!! <br> like.. it controls as good as the dreamcast version of crazy taxi at least (yes im insulting the dc version :D)  <br> and its just. a gba version of crazy taxi soooo <br> yeah" <br> anyways </span>' ;
  document.getElementById('divver').style.backgroundImage = 'url(/games/gbacart.jpg)';
}

function knid(){
 document.getElementById('title').innerHTML= '<span>kirby - nightmare in dreamland</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/BA1hY4s.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i love this game so much its. just nice! good remake :) <br> i also tried to 100% but cried not due to difficulty but just because im stupid</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/games/gbacart.jpg)';
}

function mkss(){
 document.getElementById('title').innerHTML= '<span>mario kart - super circut</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/kPkCPX6.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>have you ever wanted to play super mario kart on the go? get a 3ds <br> have you ever wanted to play a weird version of super mario kart on the go? then play this game :P <br> apparently i played this game in a car dealership </span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/games/gbacart.jpg)';
}

function pmdrrt(){
 document.getElementById('title').innerHTML= '<span>pokemon mystery dungeon - red rescue team</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/LRb3Zum.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>i beat blue rescue team and now i have no desire to complete this game. sad!</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/games/gbacart.jpg)';
}

function sa2gba(){
 document.getElementById('title').innerHTML= '<span>sonic advanced 2</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/9IfCTy4.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>this game is bleh <br> i mean its good but i think i got into it too late into my sonic hyperfix to really enjoy this game</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/games/gbacart.jpg)';
}

/* wohoo games time

function grah(){
 document.getElementById('title').innerHTML= '<span>grah</span>' ;
 document.getElementById('bigimg').innerHTML= '<img src=https://i.imgur.com/BgcRsb0.jpg width=500px>' ;
 document.getElementById('desc').innerHTML= '<span>grah</span>' ;
 document.getElementById('divver').style.backgroundImage = 'url(/images/dang.png)';
}

*/