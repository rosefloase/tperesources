

/*

function slideback1(){
hidetb();
jade.style = "position:relative; top: -7vh; left:38vh;";
setTimeout(slideback2(), 128); 
}

function slideback2(){
jade.style = "position:relative; top: -7vh; left:42vh;";
setTimeout(slideback3(), 128); 
}

function slideback3(){
jade.style = "position:relative; top: -7vh; left:20vh;";
setTimeout(slideback4(), 36); 
}

function slideback4(){
jade.style = "position:relative; top: -7vh; left:0vh;";
setTimeout(slideback5(), 36); 
}

function slideback5(){
jade.style = "position:relative; top: -7vh; right:20vh;";
setTimeout(returndownstairs1(), 36); 
} */

