 var num2 = Math.floor(Math.random() * 1);
 
 document.getElementById('num2guy').innerHTML = num2;