button id=next type="button" style="float: right; " onclick="document.getElementById('title').innerHTML = 'aaaa'; document.getElementById('para').innerHTML = 'bbbbbbbb';
     document.getElementById('next').innerHTML = url(spacedout.js);
"