function showrev(){
  document.getElementById('review').setAttribute.style.display = "inline";
}

function spike(){
 document.getElementById('title').innerHTML= '<span>Elvis Costello - Spike</span>';
 document.getElementById('image').setAttribute("src", "https://i.imgur.com/kimh6ae.jpg");  
 document.getElementById('para').innerHTML = '<span>this... is not my favorite album. but its kinda good! kinda <br> the instrumentals are alright, but the lyrics dont always hit as hard as i feel like they should... <br> its alright though! i like it :) <br><br> 6/10 - favorite track: ms macbeth </span>'; 
}

function spiritphone(){
 document.getElementById('title').innerHTML= '<span>Lemon Demon - Spirit Phone</span>';
 document.getElementById('image').setAttribute("src", "https://i.imgur.com/o3CPiw8.jpg");  
 document.getElementById('para').innerHTML = '<span>MMM this album is good... <br> its a lot more synthy than neil&apos;s older works, but is still pretty good! :3 <br> it comes in a cardwhatever case, like view-mosnter did... im scared for the case&apos;s longevity <br><br> 9/10 favorite track - when he died </span>'; 
}

function naturetapes(){
 document.getElementById('title').innerHTML= '<span>Lemon Demon - Nature Tapes</span>';
 document.getElementById('image').setAttribute("src", "https://i.imgur.com/MFDUaWw.jpg");  
 document.getElementById('para').innerHTML = '<span>im waiting for a really really bad day for me before i relisten to this album sorry guys <br><br> 10/10 - favorite track: my trains</span>'; 
}

function iambecome(){
 document.getElementById('title').innerHTML= '<span>Lemon Demon - I Am Become Christmas</span>';
 document.getElementById('image').setAttribute("src", "https://i.imgur.com/NOqU8Nu.jpg");  
 document.getElementById('para').innerHTML = '<span> -- bought on vinyl -- <br><br>neils first ep, and the harbinger of the "modern" lemon demon era! <br>its on the shorter side of lemon demon projects (~15 minutes long), but each and every song is unique and interesting :3 <br> from being depressed due to snow, to actual body horror, theres... a lot packed into this one <br><br> 8/10 - favorite track: aurora borealis</span>'; 
}

function viewmonster(){
 document.getElementById('title').innerHTML= '<span>Lemon Demon - View-Monster</span>';
 document.getElementById('image').setAttribute("src", "https://i.imgur.com/jUrgOfC.jpg");  
 document.getElementById('para').innerHTML = '<span>i love lemon demon so dont expect unbiased reviews from this website <br> view monster is the most developed of the "showdown era" albums, and it really shows in the atmosphere of the album. <br> to me at least, it feels like a somewhat hazy dreamscape, with some of the songs leaning into absurdity more than others <br> one gripe i have with the case is that its made out of cardboard... but that makes it extremely customizeable i guess, and i love the art on it... so its alright i guess <br> not all that durable though sadly :( <br><br> 10/10 - favorite track: the machine/the ocean</span>'; 
}

function dinosaurchestra(){
 document.getElementById('title').innerHTML= '<span>Lemon Demon - Dinosaurchestra</span>';
 document.getElementById('image').setAttribute("src", "https://i.imgur.com/tKqV7I4.jpg");  
 document.getElementById('para').innerHTML = '<span>oh god this was probably the first album i listened to because i wanted to <br> great lyrics, amazing instrumentals, and a summery vibe make this... probably my favorite lemon demon album. probably. <br> i dont know i like basically all of the LD albums but this one is 100% one of the best to me <br><br> 10/10 - favorite track: nothing worth loving <br> isnt askew</span>'; 
}

function damnskippy(){
 document.getElementById('title').innerHTML= '<span>Lemon Demon - Damn Skippy</span>';
 document.getElementById('image').setAttribute("src", "https://i.imgur.com/bHgM7FL.jpg");  
 document.getElementById('para').innerHTML = '<span>this album got me through 2021 damn skippy, i love you so <br> damn skippy was the fourth lemon demon album, and kickstarted the "showdown era". <br> with a faster pace than the previous albums, and a more varied pace, this is one of the first albums by neil that feels... intentionally atmospheric <br> like the last two definitely an atmosphere but it just feels more manipulated here to me <br> ...i dont think i can discuss this album without bias so <br><br> 9/10 - favorite track: subtle oddities </span>'; 
}

function httj(){
 document.getElementById('title').innerHTML= '<span>Lemon Demon - First 3 Albums (burned cds)</span>';
 document.getElementById('image').setAttribute("src", "https://i.imgur.com/SiMVuZD.jpg");  
 document.getElementById('para').innerHTML = '<span>these 3 albums were burnt on blank cds back in 2022, so im just gonna talk about them all here... <br> hip to the javabean - most developed classic ld album. was the first studio one, and it really shows in the mixing... <br> 8/10 - favorite track: relativity <br> live from the haunted candle shop - lyrically great, though a little disjointed... but i love disjointed so :P <br> 7/10 - favorite track: mold el mono <br> clown circus - first lemon demon album, and definitely feels like it... theres a lot of filler, but the better songs are still very good! <br> 6/10 - favorite track: fire motif</span>'; 
}

function astrolounge(){
 document.getElementById('title').innerHTML= '<span>Smash Mouth - Astro Lounge</span>';
 document.getElementById('image').setAttribute("src", "https://i.imgur.com/GR52CIH.jpg");  
 document.getElementById('para').innerHTML = '<span>"what did you think of this album" its pretty good <br> the instrumentals are... alright, and the lyrics are... kinda interesting! (more interesting than some other music ive listened to...) but other than that, its just. nice! <br><br> 7/10 - favorite track: radio</span>'; 
}

function simpsons(){
 document.getElementById('title').innerHTML= '<span>The Simpsons Sing the Blues</span>';
 document.getElementById('image').setAttribute("src", "https://i.imgur.com/HiKEmcW.jpg");  
 document.getElementById('para').innerHTML = '<span>i dont actually like this album <br> it just feels like it was made for people to go "oh wow the simpsons music!!!! ill take 10 please" and just. i dont think the music is for me <br><br> 5/10 - favorite song: look at all those idiots </span>'; 
}

function badhairday(){
 document.getElementById('title').innerHTML= '<span>Weird Al - Bad Hair Day</span>';
 document.getElementById('image').setAttribute("src", "https://i.imgur.com/IoE8ru7.jpg");  
 document.getElementById('para').innerHTML = '<span>uh oh! i need to relisten to these albums <br> i love weird al but i last listened to him when i was 12 </span>'; 
}

function alapalooza(){
 document.getElementById('title').innerHTML= '<span>Weird Al - Alapalooza</span>';
 document.getElementById('image').setAttribute("src", "https://i.imgur.com/kRw3xdG.jpg");  
 document.getElementById('para').innerHTML = '<span>GLUH</span>'; 
}

function normalalbum(){
 document.getElementById('title').innerHTML= '<span>Will Wood - The Normal Album</span>';
 document.getElementById('image').setAttribute("src", "/images/albums/normalalbum.jpg");  
 document.getElementById('para').innerHTML = '<span> -- bought digitally -- <br><br> this album is great it starts off with william jimmy tapeworm being mad at being forced to kill people and ends with him being glad his impact on the universe is negligable you <br> should go listen to it <br> also the instrumentals are varied and all great :D <br><br> 8/10 - favorite track: MARTHA THANKKYOU OFR THE MEDICINE</span>'; 
}

function eial(){
 document.getElementById('title').innerHTML= '<span>Will Wood - Everything is a Lot</span>';
 document.getElementById('image').setAttribute("src", "/images/albums/eial.jpg");  
 document.getElementById('para').innerHTML = '<span>--bought digitally -- <br><br> this album is... alright <br> i think i listen to will wood for the #mental illness music #not for the downward spiral of a divorced man #ok ill stop using tumblr tags. sorry <br> ...the instrumentals are great, if a little repetative throughout the album due to using the same ish set of instruments for each song <br><br> 7/10 - favorite track: front street</span>'; 
}
