function hide(){
   document.getElementById('bigimg').innerHTML = ''; 
   document.getElementById('ldcds').setAttribute("width", "300px");
   document.getElementById('myst').setAttribute("width", "300px");
   document.getElementById('cars').setAttribute("width", "300px");
   document.getElementById('dino').setAttribute("width", "300px");
   
}

function ldcds(){
 document.getElementById('bigimg').innerHTML = '<img src=https://i.imgur.com/7G9j0eT.jpg width=700px onclick=hide()>';  
   document.getElementById('ldcds').setAttribute("width", "100px"); 
   document.getElementById('myst').setAttribute("width", "100px");
   document.getElementById('cars').setAttribute("width", "100px");
   document.getElementById('dino').setAttribute("width", "100px");
}

function myst(){
 document.getElementById('bigimg').innerHTML = '<img src=https://i.imgur.com/EbTuMLN.jpg width=700px onclick=hide()>';  
   document.getElementById('ldcds').setAttribute("width", "100px"); 
   document.getElementById('myst').setAttribute("width", "100px");
   document.getElementById('cars').setAttribute("width", "100px");
   document.getElementById('dino').setAttribute("width", "100px");
}

function cars(){
 document.getElementById('bigimg').innerHTML = '<img src=https://i.imgur.com/AVLAjw0.jpg width=700px onclick=hide()>';  
   document.getElementById('ldcds').setAttribute("width", "100px"); 
   document.getElementById('myst').setAttribute("width", "100px");
   document.getElementById('cars').setAttribute("width", "100px");
   document.getElementById('dino').setAttribute("width", "100px");
}

function dino(){
 document.getElementById('bigimg').innerHTML = '<img src=https://i.imgur.com/tKqV7I4.jpg width=700px onclick=hide()>';  
   document.getElementById('ldcds').setAttribute("width", "100px"); 
   document.getElementById('myst').setAttribute("width", "100px");
   document.getElementById('cars').setAttribute("width", "100px");
   document.getElementById('dino').setAttribute("width", "100px");
}
