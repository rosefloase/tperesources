function paper2023(){
  document.getElementById('innerbleh').innerHTML = '<h2>i think i might be slowly going insane</h2> <img src=https://i.imgur.com/2n21Qyj.jpg width=500> <h2>THE DISEASE IS SPREADING</h2> <img src=https://i.imgur.com/6jHjrgF.jpg width=500> <h2> im out of erasers</h2> <img src=https://i.imgur.com/k31cbyR.jpg width=500 a> <h2> actual doodle sheet?!?!</h2> <img src=https://i.imgur.com/mgnnb2v.jpg width=500 a><h2> god i love space</h2><img src=https://i.imgur.com/aZi7rcY.jpg width=500 a>   <h2> yeah</h2> <img src=https://i.imgur.com/H6MZ0N6.jpg width=500 a> <h2> test thing of what never came to be...</h2> <img src=https://i.imgur.com/70JpWyk.jpg width=500 a>   <h2> yeah</h2> <img src=https://i.imgur.com/sCTN9oU.jpg width=500 a><h2> wow</h2> <img src=https://i.imgur.com/HtetQjG.jpg width=500 a> <h2> man i loved mice</h2> <img src=https://i.imgur.com/QQmDzNV.jpg width=500 a>   <h2> transform mice?</h2> <img src=https://i.imgur.com/vgSS3q9.jpg width=500 a>   <h2> willis!!!!!!</h2> <img src=https://i.imgur.com/QNRdhhh.jpg width=500 a>   <h2> what the HECK is a mouse</h2> <img src=https://i.imgur.com/d6E2ma0.jpg  width=500 a> <h2> ignore the taco juice stains</h2> <img src=https://i.imgur.com/JijmZnJ.jpg width=500 a>     <h2> will got stuck in my head</h2> <img src=https://i.imgur.com/0yQTTxQ.jpg  width=500 a><h2> mph</h2> <img src=https://i.imgur.com/6epEzxH.jpg  width=500 a> <h2> as the scripture foretold...</h2> <img src=https://i.imgur.com/vuahKxO.jpg width=500 a> <h2> RUN!!!!!!!!!!!!!!!</h2> <img src=https://i.imgur.com/Dfbc5yy.jpg width=500 a> <h2> Generic Traditional Pokemon Mystery Dungeon Web Comic !!!11!!1!</h2> <img src=https://i.imgur.com/G2MdsfM.jpg width=500 a><h2> my drawings take up so much space now i cant even finish one of these things</h2><img src=https://i.imgur.com/CLpERPD.jpg width=500 a> <h2> oh wow! charmandorh !</h2><img src=https://i.imgur.com/93TsTn9.jpg width=500 a><h2> huh</h2><img src=https://i.imgur.com/gvPFq9A.jpg width=500 a><h2> soupy smash brothers</h2> <img src=https://i.imgur.com/ZkFYfrY.jpg width=500 a><h2> the minty :3</h2><img src=https://i.imgur.com/nV6ac3Z.jpg width=500 a> <h2> first thing i didd</h2><img src=https://i.imgur.com/CAdHrsC.jpg width=500 a>'; 
  document.getElementById('hide').style.display = 'inline';
  document.getElementById('div').style.backgroundImage = 'url(/images/paper.png)';
}

function paperolder(){
 document.getElementById('innerbleh').innerHTML ='<h2> Something That Hurts.....</h2>  <img src=https://i.imgur.com/V8qCzaJ.jpg width=500 a><h2> action movie hero boyyyy in slow mo</h2> <img src=https://i.imgur.com/gIKUwCF.jpg width=500 a><h2> best doodle i have right now</h2> <img src=https://i.imgur.com/ATT3ZcB.jpg width=500 a><h2> another doodle i really like for some reason </h2> <img src=https://i.imgur.com/SplpJZY.jpg width=500 a><h2> one cold december night, back in 1984</h2> <img src=https://i.imgur.com/PsvbUnk.jpg width=500a><h2> mnewks >:3 </h2> <img src=https://i.imgur.com/3EWgyd6.jpg width=500 a><h2> uhhhhh idk</h2> <img src=https://i.imgur.com/qfrl2EI.jpg width=500 a>';
 document.getElementById('hide').style.display = 'inline';
 document.getElementById('div').style.backgroundImage = 'url(/images/5reams.jpeg)';
}

function computer2023(){
 document.getElementById('innerbleh').innerHTML =' <h3><span>dummyest.png</span></h3> <br> <img src=/images/dummyest.png>';
 document.getElementById('hide').style.display = 'inline';
 document.getElementById('div').style.backgroundImage = 'url(/images/shadowspin.gif)';
}

function computer2022(){
 document.getElementById('innerbleh').innerHTML ='<h2> damn skippy cat thing..</h2><img src="https://i.imgur.com/nHS9ORn.jpg" title="damn skippy cat..?" width="500"><h2>da view monshta >:3</h2>  <img src="https://i.imgur.com/ylWSfU4.jpg" title="the view monster!!!!!" width="500"><h2> uhhhh idk what this is :^]</h2>   <img src="https://i.imgur.com/IVG3b50.jpg" title="roblos charicter !" width="500">';
 document.getElementById('hide').style.display = 'inline';
  document.getElementById('div').style.backgroundImage = 'url(/images/yeah.png)';
}

function computerolder(){
 document.getElementById('innerbleh').innerHTML ='<h1>stuff i made when i was 11-12</h1><br><br><img src=/images/olds/45.png>  <br><img src=/images/olds/44.png>  <br><img src=/images/olds/43.png>  <br><img src=/images/olds/42.png>  <br><img src=/images/olds/41.png>  <br><img src=/images/olds/40.png>  <br><img src=/images/olds/39.png>  <br><img src=/images/olds/38.png>  <br><img src=/images/olds/37.png>  <br><img src=/images/olds/36.png>  <br><img src=/images/olds/35.png>  <br><img src=/images/olds/34.png>  <br><img src=/images/olds/33.png>  <br><img src=/images/olds/32.png>  <br><img src=/images/olds/31.png>  <br><img src=/images/olds/30.png>  <br><img src=/images/olds/29.png>  <br><img src=/images/olds/28.png>  <br><img src=/images/olds/27.png>  <br><img src=/images/olds/26.png>  <br><img src=/images/olds/25.png>  <br><img src=/images/olds/24.png>  <br><img src=/images/olds/23.png>  <br><img src=/images/olds/22.png>  <br><img src=/images/olds/21.png>  <br><img src=/images/olds/20.png>  <br><img src=/images/olds/19.png>  <br><img src=/images/olds/18.png>  <br><img src=/images/olds/17.png>  <br><img src=/images/olds/16.png>  <br><img src=/images/olds/15.png>  <br><img src=/images/olds/14.png>  <br><img src=/images/olds/13.png>  <br><img src=/images/olds/12.png>  <br><img src=/images/olds/11.png>  <br><img src=/images/olds/10.png><br><img src=/images/olds/9.png>  <br><img src=/images/olds/8.png>  <br><img src=/images/olds/7.png>  <br><img src=/images/olds/6.png>  <br><img src=/images/olds/5.png>  <br><img src=/images/olds/4.png>  <br><img src=/images/olds/3.png>  <br><img src=/images/olds/2.png>  <br><img src=/images/olds/1.png> ';
 document.getElementById('hide').style.display = 'inline';
  document.getElementById('div').style.backgroundImage = 'none';
}

function hide(){
 document.getElementById('innerbleh').innerHTML = ''; 
 document.getElementById('hide').style.display = 'none';
}
