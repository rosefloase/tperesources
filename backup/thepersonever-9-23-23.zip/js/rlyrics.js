function randomtext(){
  var num = Math.floor(Math.random() * 108);
  // hello onlooker!! most of these things were made in chronological order. exept for wog that was like the 8th thing i thought of. chemical overreaction was 9
  if (num == 0) {text = '<a href=https://thepersonever.neocities.org/wog.html target=_parent><span> wog. </span></a>'};
  if (num == 1) {text = '<span>from the mook to the rei to the P to the wii u gotta See hyakugojyuuichi!!!</span>'};
  if (num == 2) {text = '<span>everywhere i look, i always see...</span>'};
  if (num == 3) {text = '<span>typing this on windows xp. if you see this, hi jole! </span>'};
  if (num == 4) {text = '<span>i Have Not Showered in 36 Days!</span>'};
  if (num == 5) {text = '<span>kum n go out my mind.</span>'};
  if (num == 6) {text = '<span>, but im leavin out the whistles and bells !!</span>'};
  if (num == 7) {text = '<span>Old GodZilla Was Hoppin ARound,</span>'};
  if (num == 8) {text = '<span>IAMACHEMICAL RE AC TION!!!!</span>'};
  if (num == 9) {text = '<span>sometimes you confuse me with, santa claus... its the big white beard i suppose,, if you need me...</span>'};
  if (num == 10) {text = '<span>how many pikmin could a pikmin pluck if a pikmin could pluck pikmin?</span>'};
  if (num == 11) {text = '<span>you know, im something of a harddisk myself....</span>'};
  if (num == 12) {text = '<span>aw man i LOVE javascript!!! (ignore the day i said "i hate javascript" over and over again)</span>'};
  if (num == 13) {text = '<span>roblox lua more like stupid am i right?!?!?!?!</span>'};
  if (num == 14) {text = '<span>im slowly going insane. sorry</span>'};
  if (num == 15) {text = '<span>good lord how tall are you??? D:</span>'};
  if (num == 16) {text = '<span>alright guys, its time 2 find some LOST CSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS</span>'};
  if (num == 17) {text = '<span>you have a 1 in I Havent Decided Yet chance of seeing this. goodnight btw</span>'};
  if (num == 18) {text = '<span>$350 graphics card needed to run this site well. i hate running this site</span>'};
  if (num == 19) {text = '<span>html is fun and ez!!!!! well kinda</span>'};
  if (num == 20) {text = '<span>knife to unwanted organs!</span>'};
  if (num == 21) {text = '<span>im always out of ideas</span>'};
  if (num == 22) {text = '<span>ding-dong! doorbell!~ pie in, your face !</span>'};
  if (num == 23) {text = '<span>its plain to see, your scared of mee... but thats not how its s posed to be!</span>'};
  if (num == 24) {text = '<span>im throwing someone off a cliff. thta someone is me</span>'};
  if (num == 25) {text = '<span>weed makes me uncomfy for some reason. that being said, <br> &quot;these edibles ant Crap rose &quot; ok but this album is. puts on view monster :D</span>'};
  if (num == 26) {text = '<span>im going to eatt your livvvverrrrr~ -medic in meet the medic</span>'};
  if (num == 27) {text = '<span>how much would could a wood chuck chuck at my forehead if it could chuck wood?</span>'};
  if (num == 28) {text = '<span>im such a bad shaman. talking about mice here</span>'};
  if (num == 29) {text = '<span>NOW EVERYONE WILL BE STUPID!!!!! MUA HAHHAHAHA!!!!!!! -dobob robobnob </span>'};
  if (num == 30) {text = '<span>we&#8217;ll happen, happining, happened... we&#8217;ll happen, happening happened....</span>'};
  if (num == 31) {text = '<span>making out over minor concussions #relationship goals.... </span>'};
  if (num == 32) {text = '<span>if you didnt know, this text is randomized <3</span>'};
  if (num == 33) {text = '<span>if your from my middle school. hello there! no i do not want to date you stop asking :(</span>'};
  if (num == 34) {text = '<span>javascript is soooo fun</span>'};
  if (num == 35) {text = '<span>i installed linux mint on my windows xp laptop. bye jole :(</span>'};
  if (num == 36) {text = '<span>when i dont know what to do, i just update this. theyre my localization files <3</span>'};
  if (num == 37) {text = '<span>typing this on a chromebook. if you see this, jole, im sorry...</span>'};
  if (num == 38) {text = '<span>who is jole anyways</span>'};
  if (num == 39) {text = '<span>go play transformice!!! right now!!!! unless i know u irl</span>'};
  if (num == 40) {text = '<span>i finally did it i made randomised text me from like november 3rd 2022 is gonna be so hecking happy</span>'};
  if (num == 41) {text = '<span>tired. always and forever. zzzz</span>'};
  if (num == 42) {text = '<span>Glub glub glub glub S) (RUG.</span>'};
  if (num == 43) {text = '<span>OH NOW IMA BEAVER YEA YEA YEA YEA YEA YEAAEAH</span>'};
  if (num == 44) {text = '<span>im imploding</span>'};
  if (num == 45) {text = '<span>i havent listened to Music i Like for so long im getting intros stuck in my head</span>'};
  if (num == 46) {text = '<span>(wispering) <i>bart simpson war</i></span>'};
  if (num == 47) {text = '<span>heres the pinky, eleven stinky, take the thinky, t;urn the lights off</span>'};
  if (num == 48) {text = '<span>this is stupid dot gif</span>'};
  if (num == 49) {text = '<span>olimarrr!</span>'}; // i hate everything GRAHHHHH
  if (num == 50) {text = '<span>louie...</span>'};
  if (num == 51) {text = '<span>shackooooooo</span>'};
  if (num == 52) {text = '<span>HOMESTUCK IS REA L ITS GOING TO HAPPEN TRUST ME!!!!!!!</span>'};
  if (num == 53) {text = '<span>did you know that i m purple? cuz im not</span>'};
  if (num == 54) {text = '<span>why do i have ddr songs stuck in my head</span>'};
  if (num == 55) {text = '<span>ough. &quot;too many errors&quot; ...</span>'};
  if (num == 56) {text = '<span>homestuck cubed when? where? how?</span>'};
  if (num == 57) {text = '<span>moew</span>'};
  if (num == 58) {text = '<span>if your viewing this on windows 98 i salute you. spitfully. </span>'};
  if (num == 59) {text = '<span>your not better... your just... stupid...</span>'};
  if (num == 60) {text = '<span>insert really creative joke Here</span>'};
  if (num == 61) {text = '<span>ERROR: unnecessary semicolon more like shut!!!!!!!!!!! your mouth!!!!!!!!!!!</span>'};
  if (num == 62) {text = '<span>apparently im prospit swaying doom class but. i dont know that sounds like id just want to be that but instead id be something else</span>'};
  if (num == 63) {text = '<span>writing in javascript is going to delete my apostrophe usage...</span>'}; 
  if (num == 64) {text = '<span>i have this big google doc on my school account that i just put random html into when i have nothing to do</span>'};
  if (num == 65) {text = '<span>EYE. dont. believe it! not that Pesky .Fox! Youre still my Son...</span>'};
  if (num == 66) {text = '<span>did youknow that im both a paper moth and also jade in the Squiggle Jacket at the same time in real life</span>'};
  if (num == 67) {text = '<span>html 6 whennn???? web 3.1????</span>'};
  if (num == 68) {text = '<span>web 3.1 will remove everything 3.0 added and instead add more interactivity to websites :3 and webgpu will come to firefox</span>'};
  if (num == 69) {text = '<span>USE FIREFOX BLOCK ADS BLOCK TRACKERS!!!!!!!!</span>'};
  if (num == 70) {text = '<span>if you get any cookies from my site please email me i didnt put any in (yet...) </span>'};
  if (num == 71) {text = '<span>you wont believe how fast time flys while typing dumb sentinces</span>'};
  if (num == 72) {text = '<span>the song Currently Playing in my head changes whenever i think of something that could maybe be from a different song</span>'};
  if (num == 73) {text = '<span>did you know that karkat hates breadbugs with a burning passion</span>'};
  if (num == 74) {text = '<span>if i tried hard enough, i could get this to randomly link to a game. but i dont really wanna make a game sooooo</span>'};
  if (num == 75) {text = '<span>AAOUH - king kay rool </span>'};
  if (num == 76) {text = '<span>*put guitar trumpet solo here*</span>'};
  if (num == 77) {text = '<span>give me my sweater back or ill learn the keytar!!! (AAAAAAAAAAAAAAAA) </span>'};
  if (num == 78) {text = '<span>man i sure am cool totally mhm! yeah!</span>'};
  if (num == 79) {text = '<span>wa sting time... wast ing time... la la lalalalala wast ing time... </span>'};
  if (num == 80) {text = '<span>passing the time ist a pasketball? past basketball???? what????</span>'};
  if (num == 81) {text = '<span>:P</span>'};
  if (num == 82) {text = '<span>if only i was cooler... i wouldnt be so warm... its 800 degrees celsius </span>'};
  if (num == 83) {text = '<span>sibling fight drumbeat beatbox dot wav</span>'};
  if (num == 84) {text = '<span>meow????</span>'};
  if (num == 85) {text = '<span>quick ly i re o pen thEMM and bid you all, "cheer i o, my friend!" . this goes on for hourrrssss and it NEEvverrr seems to eeyeahnd...</span>'};
  if (num == 86) {text = '<span>Your SHIELDKIND Strife Card is badly damaged.</span>'};
  if (num == 87) {text = '<span>no way you found a secret!!! no tits no ass but i pop every balloon in transformice</span>'};
  if (num == 88) {text = '<span>FUCK YOU IM JADE IRL!!!!!!!!!!</span>'};
  if (num == 89) {text = '<span>homestuck ruined my life i used to be fine with being called rose and now i wish my legal name was jade harley</span>'};
  if (num == 90) {text = '<span>im... im lyin.... i am pregnant</span>'};
  if (num == 91) {text = '<span>im going to explode everything :D</span>'};
  if (num == 92) {text = '<span>i think im just autistic about computers in general. im normal :3</span>'};
  if (num == 93) {text = '<span>im like if jade harley lived in egbert&apos;s house</span>'};
  if (num == 94) {text = '<span>OUUUUHHHHH brainrot</span>'};
  if (num == 95) {text = '<span>thiiis is not enough!!! <i>this is not enough,</i> to prove it yet ! no i have to hit the botttoom!!!</span>'};
  if (num == 96) {text = '<span>i dont know what to say anymore</span>'};
  if (num == 97) {text = '<span>slightly unhinged!</span>'};
  if (num == 98) {text = '<span>fun fact this is kinda like splash text i think</span>'};
  if (num == 99) {text = '<span>woof</span>'};
  if (num == 100) {text = '<span>have a karkalisious 100 random text entries everytroll</span>'};
  if (num == 101) {text = '<span>GOD im so tired. being forced to do something isnt fun</span>'};
  if (num == 102) {text = '<span>im going to blow something up :D</span>'};
  if (num == 103) {text = '<span>im lik ejade harley if she</span>'};
  if (num == 104) {text = '<span>BABIES, BABIES, BABIES, BABIES,</span>'};
  if (num == 105) {text = '<span>i just finished the rewrites for everything game-related in randomjunk... guess ill just wait till i can look at my collection again before doing anything else</span>'}
  if (num == 106) {text = '<span>see you in the next dimention! its beyond our comprehension...</span>'}
  if (num == 107) {text = '<span>today i will finally get good headphones and be able to mix my music well ^_^</span>'}
  if (num == 108) {text = '<span>how do you make friends on tumblr. how</span>'}
  
document.getElementById('rtext').innerHTML = text;
document.getElementById('ntext').innerHTML = num;}

randomtext()